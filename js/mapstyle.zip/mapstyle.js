/**
 * This method creates a pre-configured set of HERE tile layers for convenient use with the
 * map.
 *
 * This method returns an object holding the three default map types
 *
 * - {@code normal}
 * - {@code satellite}
 * - {@code terrain}
 *
 * Each of the map types in turn contains the following variant tile layers:
 *
 * - {@code map}
 * - {@code xbase}
 * - {@code base}
 * - {@code traffic}
 * - {@code panorama}
 * - {@code labels}
 *
 * In addition the {@code normal} map type contains the {@code transit} variant.
 *
 * @example
 * // Create the default layers
 * var layers = platform.createDefaultLayers();
 *
 * // Set the satellite map type's traffic variant as the map's base layer
 * map.setBaseLayer(layers.satellite.traffic);
 *
 * @param {number=} opt_tileSize optional tile size to be queried from the HERE Map Tile API (default: 256)
 * @param {number=} opt_ppi optional 'ppi' parameter to use when querying tiles (default: not specified)
 * @param {string=} opt_style optional 'style' parameter to use when querying tiles (default: not specified)
 * @param {string=} opt_lg optional primary language parameter (default: not specified)
 * @param {string=} opt_lg2 optional secondary language parameter (default: not specified)
 *
 * @return {Object.<string, mapsjs.service.MapType>} a set of tile layers ready to use
 *
 * @export
 * @publish
 */
 
mapsjs.service.Platform.prototype.createDefaultLayers = function(opt_tileSize, opt_ppi, opt_style, opt_lg, opt_lg2) {
  var baseMT = this.getMapTileService(),
      aerialMT = this.getMapTileService({type: 'aerial'}),
      trafficMT = this.getMapTileService({type: 'traffic'}),
      panoMT = this.getMapTileService({type: 'pano'}),
      tileServices = [baseMT, aerialMT],
      params = {},
      groupsDict = {},
      currentGroup,
      tileSize = opt_tileSize || 256;

  if (opt_ppi) {
    params['ppi'] = opt_ppi;
  }
  if (opt_lg) {
    params['lg'] = opt_lg;
  }
  if (opt_lg2) {
    params['lg2'] = opt_lg2;
  }
  
  if (opt_style) {
    params['style'] = opt_style;
  }

  return {
    'normal': {
      'xbase': baseMT.createTileLayer('xbasetile', 'normal.day', tileSize, 'png8', params, 1, false),
      'base': baseMT.createTileLayer('basetile', 'normal.day', tileSize, 'png8', params, 1, false),
      'map': baseMT.createTileLayer('maptile', 'normal.day', tileSize, 'png8', params, 1, false),
      'traffic': trafficMT.createTileLayer('traffictile', 'normal.day', tileSize, 'png8', params, 1, false),
      'transit': baseMT.createTileLayer('maptile', 'normal.day.transit', tileSize, 'png8', params, 1, false),
      'panorama': panoMT.createTileLayer('rctile', 'normal.day', tileSize, 'png8', params, 1, false),
      'labels': baseMT.createTileLayer('labeltile', 'normal.day', tileSize, 'png', params, 1, false)
    },
    'satellite': {
      'xbase': aerialMT.createTileLayer('xbasetile', 'hybrid.day', tileSize, 'jpg', params, 1, true),
      'base': aerialMT.createTileLayer('basetile', 'hybrid.day', tileSize, 'jpg', params, 1, true),
      'map': aerialMT.createTileLayer('maptile', 'hybrid.day', tileSize, 'jpg', params, 1, true),
      'traffic': trafficMT.createTileLayer('traffictile', 'hybrid.day', tileSize, 'jpg', params, 1, true),
      'panorama': panoMT.createTileLayer('rctile', 'hybrid.day', tileSize, 'jpg', params, 1, true),
      'labels': aerialMT.createTileLayer('labeltile', 'hybrid.day', tileSize, 'png', params, 1, true)
    },
    'terrain': {
      'xbase': aerialMT.createTileLayer('xbasetile', 'terrain.day', tileSize, 'jpg', params, 1, false),
      'base': aerialMT.createTileLayer('basetile', 'terrain.day', tileSize, 'jpg', params, 1, false),
      'map': aerialMT.createTileLayer('maptile', 'terrain.day', tileSize, 'jpg', params, 1, false),
      'traffic': trafficMT.createTileLayer('traffictile', 'terrain.day', tileSize, 'jpg', params, 1, false),
      'panorama': panoMT.createTileLayer('rctile', 'terrain.day', tileSize, 'jpg', params, 1, false),
      'labels': aerialMT.createTileLayer('labeltile', 'terrain.day', tileSize, 'png', params, 1, false)
    }
  };
};
